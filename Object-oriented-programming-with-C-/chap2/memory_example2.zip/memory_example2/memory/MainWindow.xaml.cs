﻿using System.Windows;

namespace memory
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
   

        /// <summary>
        /// initialize the content of the main window
        /// </summary>
        public MainWindow()
        {
            InitializeComponent(); 
        }

    }
}
