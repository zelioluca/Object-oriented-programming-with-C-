﻿
namespace Memory_only
{
    class Markers
    {
        //content if the square is not turned
        public static char Empty = ' ';
        //content of squares  
        public static char[]  Selection= { 
                                   '½', '§', '!', '1', '\'','2', '@', '#', '3', '£',
                                   '¤', '4', '%', '5', '&', '6', '/', '7', '(', '\\',
                                   '8', '[', ')', '9', ']', '=', '0', '}', '?', '+', 
                                   'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', '/',
                                   'P', 'Å', '^', '¨', '~', 'A', 'S', 'D', 'F', 'G', 
                                   'H', 'J', 'K', 'L', 'Ö', 'Ä', '*', '"', '>', '<', 
                                   '|', 'Z', 'X', 'C', 'V','B',  'N', 'M', ';', ',',
                                   ':', '.'};
    }
}
