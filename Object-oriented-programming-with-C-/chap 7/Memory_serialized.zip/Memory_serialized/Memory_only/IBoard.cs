﻿using System;
namespace Memory_only
{
    interface IBoard
    {
        void InitBoard();
    }
}
