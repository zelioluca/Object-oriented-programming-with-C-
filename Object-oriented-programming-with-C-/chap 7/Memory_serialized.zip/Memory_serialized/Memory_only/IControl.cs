﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Memory_only
{
    public interface IControl
    {
        void Set();

        void Reset();
    }
}
