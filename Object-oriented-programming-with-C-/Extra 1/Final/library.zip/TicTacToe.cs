﻿//shows only the parameterized constructor and Play method 
//add in the rest so that the game is functioning as it did with only one class 

using System;
using System.Windows;
using System.Windows.Controls;

namespace boardgames
{
    class TicTacToe : BoardGame
    {
        new protected Button[] places = new Button[9];
        //copy of buttons in the user interface 
        //amount of moves in one game 
        private int moves;

        public TicTacToe(TTTBoard tTTBoard)
        {
            //copy reference of buttons in Grid named grid to slots table 
            tTTBoard.grid.Children.CopyTo(places, 0);
            Init();
        }

        /// <summary> 
        /// make a move and machine's counter move  
        /// </summary> 
        /// <param name="sender">button where the event was raised</param> 
        public override void Play(object sender)
        {
            //message shows user the situation of the game 
            string message = "";
            // user move 
            Move(sender);

            if (AnnounceSituation(Check(), ref message))//has the game ended? 
            {
                NewGame(message);
            }
            else
            {
                //machine move, this point is not reached if the game ended after user's move 
                MachineMove();

                if (AnnounceSituation(Check(), ref message))//has the game ended? 
                {
                    NewGame(message);
                }
            }
        }
        private void NewGame(string message)
        {
            if (MessageBox.Show("Do you want to start a new game", message, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Init();
            }
            else
            {
                Application.Current.Shutdown();
                //this.Close();
            }
        }
        public override void NewGame()
        {

        }
        /// <summary> 
        /// places machine's mark O  
        /// </summary> 
        private void MachineMove()
        {
            int place;
            //search for availabe place  
            //NOTE might search forever 
            while (true)
            {
                place = new Random().Next(9);
                if (places[place].IsEnabled)
                {
                    places[place].Content = "O";
                    //prevent the other marks  
                    places[place].IsEnabled = false;
                    moves++;
                    break;
                }
            }

        }

        /// <summary> 
        /// places user's mark X 
        /// </summary> 
        /// <param name="sender">the button user picked</param> 
        private void Move(object sender)
        {

            //one possible way to find out the index of the button 
            Button b = (Button)sender;
            b.IsEnabled = false;
            //int place = 0;
            //while (true)
            //{
            //    if (slots[place] == b)
            //        break;
            //    place++;
            //}
            ////prevent the other marks  
            //slots[place].IsEnabled = false;
            b.Content = "X";
            moves++;
        }

        /// <summary> 
        /// checks if the game is ended (win, lose, draw) 
        /// </summary> 
        /// <returns>returns the mark of the winner</returns> 
        private string Check()
        {
            string winner = "";
            //go through the buttons table 

            for (int i = 0; i < 9; i++)
            {
                //columns 
                if ((i == 0) || (i == 3) || (i == 6))
                {
                    //horizontal
                    if (((places[i].Content.ToString() == places[i + 1].Content.ToString()) &&
                        (places[i].Content.ToString() == places[i + 2].Content.ToString()) &&
                        (places[i].Content.ToString() != "")))
                    {
                        winner = places[i].Content.ToString();
                    }
                    //vertical
                    else if (((places[i].Content.ToString() == places[(i + 3) % 9].Content.ToString()) &&
                        (places[i].Content.ToString() == places[(i + 6) % 9].Content.ToString()) &&
                        (places[i].Content.ToString() != "")))
                    {
                        winner = places[i].Content.ToString();
                    }
                    //digonal
                    else if ((i == 0) && ((places[i].Content.ToString() == places[4].Content.ToString()) &&
                        (places[i].Content.ToString() == places[8].Content.ToString()) &&
                        (places[i].Content.ToString() != "")))
                    {
                        winner = places[i].Content.ToString();
                    }
                    //digonal
                    else if ((i == 6) && ((places[i].Content.ToString() == places[2].Content.ToString()) &&
                        (places[i].Content.ToString() == places[4].Content.ToString()) &&
                        (places[i].Content.ToString() != "")))
                    {
                        winner = places[i].Content.ToString();
                    }
                }
                else if ((i == 1) || (i == 2))
                {
                    if (((places[i].Content.ToString() == places[(i + 3) % 9].Content.ToString()) &&
                        (places[i].Content.ToString() == places[(i + 6) % 9].Content.ToString()) &&
                        (places[i].Content.ToString() != "")))
                    {
                        winner = places[i].Content.ToString();
                    }

                }
            }
            return winner;
        }

        /// <summary> 
        /// based on the winners mark given as a parameter returns true if the game is over 
        /// </summary> 
        /// <param name="winner">winners mark O, X or empty</param> 
        /// <param name="message">infor text as reference</param> 
        /// <returns>true = game over, false = game continues</returns> 
        private bool AnnounceSituation(string winner, ref string message)
        {
            bool end = false;

            //is the game over? 
            if (winner == "X")
            {
                message = "You won, " + winner;
                end = true;
            }
            else if (winner == "O")
            {
                message = "You lost and  " + winner + " wins"; ;
                end = true;
            }
            else if (moves == 9)
            {
                message = "It's a tie";
                end = true;
            }
            return end;
        }

        /// <summary> 
        ///  
        /// reset all buttons and moves 
        /// </summary> 
        public override void Init()
        {
            //set empty string to every button's content 
            for (int i = 0; i < 9; i++)
            {
                places[i].Content = "";
                places[i].IsEnabled = true;
                moves = 0;
            }
        }
    }
}