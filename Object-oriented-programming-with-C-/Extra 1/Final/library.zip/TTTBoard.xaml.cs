﻿
using System.Windows;
using System.Windows.Controls;

namespace boardgames
{
    /// <summary> 
    /// Interaction logic for TTTBoard.xaml 
    /// </summary> 
    public partial class TTTBoard : UserControl
    {
        private TicTacToe game;
        public TTTBoard()
        {
            InitializeComponent();
            game = new TicTacToe(this);
        }

        /// <summary> 
        /// dispatches the reference of the button that raised the event to 
        /// TTTBoard object called game 
        /// </summary> 
        /// <param name="sender"></param> 
        /// <param name="e"></param> 
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            game.Play(sender);
        }
    }
}