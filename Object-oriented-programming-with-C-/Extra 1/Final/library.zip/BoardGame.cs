﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace boardgames
{
    public abstract class BoardGame : IBoardGame
    {
        protected UIElement[] places;

        public abstract void Init();
        public abstract void NewGame();
        public abstract void Play(object sender);
    }

}
